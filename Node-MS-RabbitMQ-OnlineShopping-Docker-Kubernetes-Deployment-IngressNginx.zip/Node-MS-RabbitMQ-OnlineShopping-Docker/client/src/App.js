import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./components/listofproducts";

function App() {
  return (
    <div className="App">
      <ListOfProducts />
    </div>
  );
}

export default App;
